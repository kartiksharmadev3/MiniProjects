package com.codingChallenge.accountDetails.controller;

import com.codingChallenge.accountDetails.dto.UserDTO;
import com.codingChallenge.accountDetails.exception.ResourceNotFoundException;
import com.codingChallenge.accountDetails.response.ApiResponse;
import com.codingChallenge.accountDetails.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/api/v1/users")
@Api(tags = "1. user-controller", description = "Endpoints for retrieving user details")
public class UserController {
    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    @ApiOperation(
            value = "Retrieve all users",
            notes = "Fetches a list of all registered users with their basic details."
    )
    public ResponseEntity<ApiResponse<List<UserDTO>>> getAllUsers() {
        log.info("Retrieving all users");
        List<UserDTO> userDTOList = userService.getAllUsers().orElseThrow(() -> new ResourceNotFoundException("No Users Exists"));
        return ResponseEntity.ok(new ApiResponse<List<UserDTO>>(true, "User(s) fetched successfully", userDTOList));
    }
}