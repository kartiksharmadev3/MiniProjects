package com.codingChallenge.accountDetails.service;
import com.codingChallenge.accountDetails.dto.AccountDTO;

import java.util.List;

public interface AccountService {
    List<AccountDTO> getAccountsByUserId(Long userId);
    AccountDTO getAccountByAccountNumber(String accountNumber);
}
