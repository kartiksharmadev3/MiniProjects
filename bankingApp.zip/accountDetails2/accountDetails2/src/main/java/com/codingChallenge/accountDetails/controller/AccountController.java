package com.codingChallenge.accountDetails.controller;

import com.codingChallenge.accountDetails.dto.AccountDTO;
import com.codingChallenge.accountDetails.response.ApiResponse;
import com.codingChallenge.accountDetails.service.AccountService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/accounts")
@Api(tags = "2. account-controller", description = "Endpoints for retrieving user account details")
public class AccountController {

    private static final Logger log = LoggerFactory.getLogger(AccountController.class);

    private final AccountService accountService;

    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @GetMapping("/user/{userId}")
    @ApiOperation(
            value = "Retrieve all accounts for a user",
            notes = "Fetches all accounts linked to a given user ID, including account name, type, balance, and currency details."
    )
    public ResponseEntity<ApiResponse<List<AccountDTO>>> getAccountsByUserId(@PathVariable Long userId) {
        log.info("Retrieving accounts for user ID: {}", userId);
        List<AccountDTO> accounts = accountService.getAccountsByUserId(userId);

        if (accounts.isEmpty()) {
            log.warn("No accounts found for user ID: {}", userId);
            return ResponseEntity.status(404)
                    .body(new ApiResponse<>(false, "No accounts found for user ID: " + userId, null));
        }
        log.info("Accounts retrieved successfully for user ID: {}", userId);
        return ResponseEntity.ok(new ApiResponse<>(true, "Accounts retrieved successfully", accounts));
    }
}
