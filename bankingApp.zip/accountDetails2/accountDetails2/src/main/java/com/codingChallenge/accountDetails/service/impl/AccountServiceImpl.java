package com.codingChallenge.accountDetails.service.impl;

import com.codingChallenge.accountDetails.dto.AccountDTO;
import com.codingChallenge.accountDetails.exception.ResourceNotFoundException;
import com.codingChallenge.accountDetails.model.Account;
import com.codingChallenge.accountDetails.repository.AccountRepository;
import com.codingChallenge.accountDetails.service.AccountService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AccountServiceImpl implements AccountService {
    private static final Logger log = LoggerFactory.getLogger(AccountServiceImpl.class);

    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public List<AccountDTO> getAccountsByUserId(Long userId) {
        List<Account> accounts = accountRepository.findByUserId(userId).orElseThrow(() -> new ResourceNotFoundException("No accounts found for user ID: " + userId));
        return accounts.stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Override
    public AccountDTO getAccountByAccountNumber(String accountNumber) {
        Account account = accountRepository.findByAccountNumber(accountNumber).orElseThrow(() -> new ResourceNotFoundException("Account not Exists"));
        return mapToDTO(account);
    }

    private AccountDTO mapToDTO(Account account){
        AccountDTO dto = new AccountDTO();
        dto.setAccountNumber(account.getAccountNumber());
        dto.setAccountName(account.getAccountName());
        dto.setAccountType(account.getAccountType());
        dto.setBalanceDate(account.getBalanceDate());
        dto.setCurrency(account.getCurrency());
        dto.setOpeningAvailableBalance(account.getOpeningAvailableBalance());
        return dto;
    }
}
