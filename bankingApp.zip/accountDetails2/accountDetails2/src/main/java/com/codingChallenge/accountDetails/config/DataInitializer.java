package com.codingChallenge.accountDetails.config;

import com.codingChallenge.accountDetails.model.Account;
import com.codingChallenge.accountDetails.model.Transaction;
import com.codingChallenge.accountDetails.model.User;
import com.codingChallenge.accountDetails.repository.AccountRepository;
import com.codingChallenge.accountDetails.repository.TransactionRepository;
import com.codingChallenge.accountDetails.repository.UserRepository;
import com.github.javafaker.Faker;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Random;

@Component
public class DataInitializer {

    private final UserRepository userRepository;
    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final Faker faker = new Faker();
    private final Random random = new Random();

    public DataInitializer(UserRepository userRepository, AccountRepository accountRepository, TransactionRepository transactionRepository) {
        this.userRepository = userRepository;
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
    }

    @PostConstruct
    public void initData() {
        String[] currencies = {"USD", "EUR", "INR", "GBP"};
        String[] accountTypes = {"Savings", "Current", "Business"};
        String[] cardTypes = {"DebitCard", "CreditCard"};

        int numUsers = 3;
        int numAccountsPerUser = 8;
        int numTransactionsPerAccount = 8;

        for (int i = 0; i < numUsers; i++) {
            User user = new User();
            user.setId(generateUniqueId());
            user.setName(faker.name().fullName());
            userRepository.save(user);

            for (int j = 0; j < numAccountsPerUser; j++) {
                Account account = new Account();
                account.setAccountNumber(generateUniqueAccountNumber());
                account.setAccountName(faker.company().name());
                account.setAccountType(accountTypes[random.nextInt(accountTypes.length)]);
                account.setBalanceDate(LocalDate.now().minusDays(random.nextInt(365)));
                account.setCurrency(currencies[random.nextInt(currencies.length)]);
                account.setOpeningAvailableBalance(BigDecimal.valueOf(random.nextDouble() * 10000));
                account.setUser(user);
                accountRepository.save(account);

                for (int k = 0; k < numTransactionsPerAccount; k++) {
                    Transaction transaction = new Transaction();
                    transaction.setTransactionId(generateUniqueTransactionId());
                    transaction.setAccount(account);
                    transaction.setAccountName(account.getAccountName());
                    transaction.setValueDate(LocalDate.now().minusDays(random.nextInt(30)));
                    transaction.setCurrency(account.getCurrency());
                    transaction.setCardType(cardTypes[random.nextInt(cardTypes.length)]);

                    // Randomly decide if it's a debit or credit transaction
                    boolean isDebit = random.nextBoolean();
                    if (isDebit) {
                        transaction.setDebitAmount(BigDecimal.valueOf(random.nextDouble() * 500));
                        transaction.setCreditAmount(null);
                    } else {
                        transaction.setCreditAmount(BigDecimal.valueOf(random.nextDouble() * 500));
                        transaction.setDebitAmount(null);
                    }

                    transaction.setTransactionNarrative(faker.lorem().sentence());
                    transactionRepository.save(transaction);
                }
            }
        }
    }

    private Long generateUniqueId() {
        return (Long) faker.number().randomNumber(5, true);
    }

    private String generateUniqueAccountNumber() {
        return String.valueOf(faker.number().numberBetween(1000000000L, 9999999999L)); // 10-digit numeric string
    }

    private String generateUniqueTransactionId() {
        return String.valueOf(faker.number().numberBetween(1000000000000000L, 9999999999999999L)); // 16-digit numeric string
    }
}
