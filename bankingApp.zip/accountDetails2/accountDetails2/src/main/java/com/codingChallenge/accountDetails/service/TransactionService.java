package com.codingChallenge.accountDetails.service;

import com.codingChallenge.accountDetails.dto.TransactionDTO;

import java.util.List;

public interface TransactionService {
    List<TransactionDTO> getTransactionsByAccountNumber(String accountNumber);
}
