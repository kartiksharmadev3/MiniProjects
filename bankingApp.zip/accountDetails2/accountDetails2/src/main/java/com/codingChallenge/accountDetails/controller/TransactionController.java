package com.codingChallenge.accountDetails.controller;

import com.codingChallenge.accountDetails.dto.TransactionDTO;
import com.codingChallenge.accountDetails.response.ApiResponse;
import com.codingChallenge.accountDetails.service.TransactionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/transactions")
@Api(tags = "3. transaction-controller", description = "Endpoints for retrieving account transaction details")
public class TransactionController {
    private static final Logger log = LoggerFactory.getLogger(TransactionController.class);

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @GetMapping("/account/{accountNumber}")
    @ApiOperation(
            value = "Retrieve all transactions for an account",
            notes = "Fetches all transactions linked to a given account number, including transaction type, amount, currency, and date."
    )
    public ResponseEntity<ApiResponse<List<TransactionDTO>>> getTransactionsByAccountNumber(@PathVariable String accountNumber) {
        log.info("Retrieving transactions for account number: {}", accountNumber);
        List<TransactionDTO> transactions = transactionService.getTransactionsByAccountNumber(accountNumber);

        if (transactions.isEmpty()) {
            log.warn("No transactions found for account number: {}", accountNumber);
            return ResponseEntity.status(404)
                    .body(new ApiResponse<>(false, "No transactions found for account number: " + accountNumber, null));
        }
        log.info("Transactions retrieved successfully for account number: {}", accountNumber);
        return ResponseEntity.ok(new ApiResponse<>(true, "Transactions retrieved successfully", transactions));
    }
}
