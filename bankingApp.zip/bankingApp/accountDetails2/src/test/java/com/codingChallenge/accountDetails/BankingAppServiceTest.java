package com.codingChallenge.accountDetails;

import com.codingChallenge.accountDetails.dto.AccountDTO;
import com.codingChallenge.accountDetails.dto.TransactionDTO;
import com.codingChallenge.accountDetails.dto.UserDTO;
import com.codingChallenge.accountDetails.model.Account;
import com.codingChallenge.accountDetails.model.Transaction;
import com.codingChallenge.accountDetails.model.User;
import com.codingChallenge.accountDetails.repository.AccountRepository;
import com.codingChallenge.accountDetails.repository.TransactionRepository;
import com.codingChallenge.accountDetails.repository.UserRepository;
import com.codingChallenge.accountDetails.service.impl.AccountServiceImpl;
import com.codingChallenge.accountDetails.service.impl.TransactionServiceImpl;
import com.codingChallenge.accountDetails.service.impl.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BankingAppServiceTest {
    @Mock
    private UserRepository userRepository;

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private TransactionRepository transactionRepository;

    @InjectMocks
    private UserServiceImpl userService;

    @InjectMocks
    private AccountServiceImpl accountService;

    @InjectMocks
    private TransactionServiceImpl transactionService;

    private User testUser;
    private Account testAccount;
    private Transaction testTransaction;

    @BeforeEach
    void setUp() {
        // Set up test user
        testUser = new User();
        testUser.setId(Long.valueOf(1L));
        testUser.setName("John Doe");

        // Set up test account
        testAccount = new Account();
        testAccount.setAccountNumber("123456");
        testAccount.setAccountName("John Doe Savings");
        testAccount.setAccountType("Savings");
        testAccount.setBalanceDate(LocalDate.now());
        testAccount.setCurrency("USD");
        testAccount.setOpeningAvailableBalance(BigDecimal.valueOf(5000));
        testAccount.setUser(testUser);

        // Set up test transaction
        testTransaction = new Transaction();
        testTransaction.setTransactionId("T123");
        testTransaction.setAccount(testAccount);
        testTransaction.setAccountName("John Doe Savings");
        testTransaction.setValueDate(LocalDate.now());
        testTransaction.setCurrency("USD");
        testTransaction.setDebitAmount(BigDecimal.valueOf(100));
        testTransaction.setCreditAmount(null);
        testTransaction.setCardType("DebitCard");
        testTransaction.setTransactionNarrative("Purchase at store");
    }


    @Test
    void testGetUserByUserId() {
        when(userRepository.findById(Long.valueOf(1L))).thenReturn(Optional.of(testUser));

        UserDTO result = userService.getUserByUserId(Long.valueOf(1L));

        assertTrue(result.getId() == 1);
        assertEquals("John Doe", result.getName());

        verify(userRepository, times(1)).findById(Long.valueOf(1L));
    }

    @Test
    void testGetAccountByAccountNumber() {
        when(accountRepository.findByAccountNumber("123456")).thenReturn(Optional.of(testAccount));

        AccountDTO result = accountService.getAccountByAccountNumber("123456");

        assertNotNull(result);
        assertEquals("123456", result.getAccountNumber());
        assertEquals("John Doe Savings", result.getAccountName());

        verify(accountRepository, times(1)).findByAccountNumber("123456");
    }

    @Test
    void testGetAccountsByUserId() {
        when(accountRepository.findByUserId(Long.valueOf(1L))).thenReturn(Optional.of(Arrays.asList(testAccount)));

        List<AccountDTO> result = accountService.getAccountsByUserId(Long.valueOf(1L));

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("123456", result.get(0).getAccountNumber());

        verify(accountRepository, times(1)).findByUserId(Long.valueOf(1L));
    }


    @Test
    void testGetTransactionsByAccountNumber() {
        when(transactionRepository.findByAccountAccountNumber("123456")).thenReturn(Arrays.asList(testTransaction));

        List<TransactionDTO> result = transactionService.getTransactionsByAccountNumber("123456");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("T123", result.get(0).getTransactionId());

        verify(transactionRepository, times(1)).findByAccountAccountNumber("123456");
    }
}
