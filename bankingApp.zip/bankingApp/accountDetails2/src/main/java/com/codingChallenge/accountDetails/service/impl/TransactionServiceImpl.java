package com.codingChallenge.accountDetails.service.impl;

import com.codingChallenge.accountDetails.dto.TransactionDTO;
import com.codingChallenge.accountDetails.exception.ResourceNotFoundException;
import com.codingChallenge.accountDetails.model.Transaction;
import com.codingChallenge.accountDetails.repository.TransactionRepository;
import com.codingChallenge.accountDetails.service.TransactionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransactionServiceImpl implements TransactionService {
    private static final Logger log = LoggerFactory.getLogger(TransactionServiceImpl.class);

    private final TransactionRepository transactionRepository;

    public TransactionServiceImpl(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    @Override
    public List<TransactionDTO> getTransactionsByAccountNumber(String accountNumber) {
        log.info("Retrieving transactions for account number: {}", accountNumber);
        List<Transaction> transactions = transactionRepository.findByAccountAccountNumber(accountNumber);
        if (transactions.isEmpty()) {
            throw new ResourceNotFoundException("No transactions found for account number: " + accountNumber);
        }

        return transactions.stream().map(transaction -> {
            TransactionDTO dto = new TransactionDTO();
            dto.setTransactionId(transaction.getTransactionId());
            dto.setAccountName(transaction.getAccountName());
            dto.setValueDate(transaction.getValueDate());
            dto.setCurrency(transaction.getCurrency());
            dto.setDebitAmount(transaction.getDebitAmount());
            dto.setCreditAmount(transaction.getCreditAmount());
            dto.setCardType(transaction.getCardType());
            dto.setTransactionNarrative(transaction.getTransactionNarrative());
            return dto;
        }).collect(Collectors.toList());
    }
}
