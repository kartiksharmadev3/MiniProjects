package com.codingChallenge.accountDetails.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class TransactionDTO {
    private String transactionId;
    private String accountName;
    private LocalDate valueDate;
    private String currency;
    private BigDecimal debitAmount;
    private BigDecimal creditAmount;
    private String cardType;
    private String transactionNarrative;

    public TransactionDTO(String transactionId, String accountName, LocalDate valueDate, String currency, BigDecimal debitAmount, BigDecimal creditAmount, String cardType, String transactionNarrative) {
        this.transactionId = transactionId;
        this.accountName = accountName;
        this.valueDate = valueDate;
        this.currency = currency;
        this.debitAmount = debitAmount;
        this.creditAmount = creditAmount;
        this.cardType = cardType;
        this.transactionNarrative = transactionNarrative;
    }

    public TransactionDTO() {
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getAccountName() {
        return accountName;
    }

    public LocalDate getValueDate() {
        return valueDate;
    }

    public String getCurrency() {
        return currency;
    }

    public BigDecimal getDebitAmount() {
        return debitAmount;
    }

    public BigDecimal getCreditAmount() {
        return creditAmount;
    }

    public String getCardType() {
        return cardType;
    }

    public String getTransactionNarrative() {
        return transactionNarrative;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public void setValueDate(LocalDate valueDate) {
        this.valueDate = valueDate;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setDebitAmount(BigDecimal debitAmount) {
        this.debitAmount = debitAmount;
    }

    public void setCreditAmount(BigDecimal creditAmount) {
        this.creditAmount = creditAmount;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public void setTransactionNarrative(String transactionNarrative) {
        this.transactionNarrative = transactionNarrative;
    }
}
