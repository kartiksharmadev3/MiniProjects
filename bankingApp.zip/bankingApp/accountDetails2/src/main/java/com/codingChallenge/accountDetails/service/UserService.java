package com.codingChallenge.accountDetails.service;

import com.codingChallenge.accountDetails.dto.UserDTO;

import java.util.List;
import java.util.Optional;

public interface UserService {
    Optional<List<UserDTO>> getAllUsers();
    UserDTO getUserByUserId(Long userId);
}
