package com.codingChallenge.accountDetails.model;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    private String transactionId;

    @ManyToOne
    @JoinColumn(name = "account_number", nullable = false)
    private Account account;

    @Column(nullable = false)
    private String accountName;

    @Column(nullable = false)
    private LocalDate valueDate;

    @Column(nullable = false)
    private String currency;

    @Column(nullable = true)
    private BigDecimal debitAmount;

    @Column(nullable = true)
    private BigDecimal creditAmount;

    @Column(nullable = false)
    private String cardType;  // "DebitCard" / "CreditCard"

    @Column(nullable = true)
    private String transactionNarrative;


    public Transaction(String transactionId, Account account, String accountName, LocalDate valueDate, String currency, BigDecimal debitAmount, BigDecimal creditAmount, String cardType, String transactionNarrative) {
        this.transactionId = transactionId;
        this.account = account;
        this.accountName = accountName;
        this.valueDate = valueDate;
        this.currency = currency;
        this.debitAmount = debitAmount;
        this.creditAmount = creditAmount;
        this.cardType = cardType;
        this.transactionNarrative = transactionNarrative;
    }

    public Transaction() {
    }

    public String getTransactionId() {
        return transactionId;
    }

    public Account getAccount() {
        return account;
    }

    public String getAccountName() {
        return accountName;
    }

    public LocalDate getValueDate() {
        return valueDate;
    }

    public String getCurrency() {
        return currency;
    }

    public BigDecimal getDebitAmount() {
        return debitAmount;
    }

    public BigDecimal getCreditAmount() {
        return creditAmount;
    }

    public String getCardType() {
        return cardType;
    }

    public String getTransactionNarrative() {
        return transactionNarrative;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public void setValueDate(LocalDate valueDate) {
        this.valueDate = valueDate;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setDebitAmount(BigDecimal debitAmount) {
        this.debitAmount = debitAmount;
    }

    public void setCreditAmount(BigDecimal creditAmount) {
        this.creditAmount = creditAmount;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public void setTransactionNarrative(String transactionNarrative) {
        this.transactionNarrative = transactionNarrative;
    }
}