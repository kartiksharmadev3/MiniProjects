package com.codingChallenge.accountDetails.service.impl;

import com.codingChallenge.accountDetails.dto.UserDTO;
import com.codingChallenge.accountDetails.exception.ResourceNotFoundException;
import com.codingChallenge.accountDetails.model.User;
import com.codingChallenge.accountDetails.repository.UserRepository;
import com.codingChallenge.accountDetails.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public Optional<List<UserDTO>> getAllUsers() {
        return Optional.of(userRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList()));
    }

    @Override
    public UserDTO getUserByUserId(Long userId) {
        Optional<User> userOptional = userRepository.findById(userId);
        User user = userOptional.orElseThrow(() -> new ResourceNotFoundException("User not exists"));
        return mapToDTO(user);
    }

    private UserDTO mapToDTO(User user) {
        UserDTO dto = new UserDTO();
        dto.setId(user.getId());
        dto.setName(user.getName());
        return dto;
    }
}
