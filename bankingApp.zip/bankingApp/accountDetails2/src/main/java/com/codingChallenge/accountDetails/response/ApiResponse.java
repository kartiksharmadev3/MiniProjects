package com.codingChallenge.accountDetails.response;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.time.LocalDateTime;

public class ApiResponse<T> {
    @JsonIgnore
    private boolean success;
    private String status;
    private String message;
    private T data;
    private LocalDateTime timestamp;


    public ApiResponse(boolean success, String message, T data) {
        this.success = success;
        this.status = success ? "SUCCESS" : "FAILURE";
        this.message = message;
        this.data = data;
        this.timestamp = LocalDateTime.now();
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public T getData() {
        return data;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getStatus() {
        return status;
    }
}
